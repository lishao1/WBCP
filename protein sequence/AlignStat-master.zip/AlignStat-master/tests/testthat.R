library(testthat)
library(AlignStat)

test_check("AlignStat")
