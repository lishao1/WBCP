#' Comparison Alignment
#'
#' An example alignment 
#'
#' @format A data frame with sequences in columns and amino acid in rows"comparison_alignment"
"comparison_alignment"

#' Reference Alignment
#'
#' An example alignment 
#'
#' @format A data frame with sequences in columns and amino acid in rows
"reference_alignment"
